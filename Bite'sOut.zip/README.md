Swaps the regenerative property of Acrid\'s bite for reset cooldowns on
kill.
